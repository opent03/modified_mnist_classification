# modified_mnist_classification
mnist but with more numbers in a single picture. Using various models, we tackle this 10-class classification problem in Python3.


Install requirements by running: pip3 install requirements.txt

To run modules inside models, use : python3 -m models.<python file>

For pretrained weights, please email me. 

